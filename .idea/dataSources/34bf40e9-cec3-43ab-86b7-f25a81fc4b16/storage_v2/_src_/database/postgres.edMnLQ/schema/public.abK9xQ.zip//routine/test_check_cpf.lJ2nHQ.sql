CREATE FUNCTION test_check_cpf()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  ASSERT check_cpf(95115469103), 'A valid cpf must pass the test';
  ASSERT (NOT check_cpf(0)), 'Invalid cpf 000.000.000-00 must not pass the test';
  ASSERT (NOT check_cpf(11111111111)), 'Invalid cpf 111.111.111-11 must not pass the test';
  ASSERT (NOT check_cpf(22222222222)), 'Invalid cpf 222.222.222-22 must not pass the test';
  ASSERT (NOT check_cpf(33333333333)), 'Invalid cpf 333.333.333-33 must not pass the test';
  ASSERT (NOT check_cpf(44444444444)), 'Invalid cpf 444.444.444-44 must not pass the test';
  ASSERT (NOT check_cpf(55555555555)), 'Invalid cpf 555.555.555-55 must not pass the test';
  ASSERT (NOT check_cpf(66666666666)), 'Invalid cpf 666.666.666-66 must not pass the test';
  ASSERT (NOT check_cpf(77777777777)), 'Invalid cpf 777.777.777-77 must not pass the test';
  ASSERT (NOT check_cpf(88888888888)), 'Invalid cpf 888.888.888-88 must not pass the test';
  ASSERT (NOT check_cpf(99999999999)), 'Invalid cpf 999.999.999-99 must not pass the test';

END;
$$;

