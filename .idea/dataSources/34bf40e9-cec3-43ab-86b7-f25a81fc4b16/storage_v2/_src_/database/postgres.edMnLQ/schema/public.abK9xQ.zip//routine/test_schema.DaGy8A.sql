CREATE FUNCTION test_schema()
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  ASSERT (SELECT 1 from information_schema.tables WHERE table_name = 'user'), 'Table user must exist';
  ASSERT (SELECT 1 from information_schema.tables WHERE table_name = 'user_email'), 'Table user_email must exist';
  ASSERT (SELECT 1 from information_schema.tables WHERE table_name = 'user_phone'), 'Table user_phone must exist';
END;
$$;

